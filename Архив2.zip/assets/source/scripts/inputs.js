$(document).ready(function() {


	$('.banner__form__input__placeholder').click(function() {
		$(this).parent().find('.banner__form__input').focus();
	});

	$('.banner__form__input__placeholder').on('mouseenter', function() {
		$(this).parent().find('.banner__form__input').addClass('hover');
	});

	$('.banner__form__input__placeholder').on('mouseleave', function() {
		$(this).parent().find('.banner__form__input').removeClass('hover');
	});


	$('.banner__form__input__clear').on('click',function(){
		$(this).parent().find('.banner__form__input').val('');
		$(this).parent().find('.banner__form__input').focusout();
	});

	console.log(navigator.userAgent.toLowerCase());

	if (navigator.userAgent.toLowerCase().indexOf('mozilla') > -1) {
		$('body').addClass('ie');
	}

	if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1 || navigator.userAgent.toLowerCase().indexOf('mozilla') > -1){
	     $('.banner__form__input').on('focus', function() {
	     	$(this).addClass('focus');
	     	$(this).parent().find('.banner__form__input__placeholder').addClass('focus');
	     });

	     $('.banner__form__input').on('focusout', function() {
	     	if ($(this).val().length == 0) {
	     		$(this).removeClass('focus');
	     		$(this).parent().find('.banner__form__input__placeholder').removeClass('focus');
	     		$(this).parent().find('.banner__form__input__clear').removeClass('ready');
	     	}

	     	else {
	     		$(this).parent().find('.banner__form__input__clear').addClass('ready');
	     	}
	     	
	     });



	     $('.banner__form__checkbox').addClass('go');
	     $('.banner__form__checkbox__span').addClass('go');


	}

	


});