!function(n){var u="mmenu";n[u].i18n({Menu:"Меню"})}(jQuery);
!function(e){var u="mmenu";e[u].i18n({"Close menu":"Закрыть меню","Close submenu":"Закрыть подменю","Open submenu":"Открыть подменю","Toggle submenu":"Переключить подменю"})}(jQuery);
!function(e){var n="mmenu";e[n].i18n({Search:"Найти","No results found.":"Ничего не найдено.",cancel:"Отмена"})}(jQuery);