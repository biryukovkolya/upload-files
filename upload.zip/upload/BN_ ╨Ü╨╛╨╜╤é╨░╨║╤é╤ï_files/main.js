(function ($) {
    // start general var
    var $window = $(window);
    // end general var


    // start mmenu
    var $navBarTop = $('.nav-bar_top');
    var $navBarMenuTop = $('#nav-bar__menu_top');
    var $nabBarMenuTopPlugin = $navBarMenuTop.mmenu({
        'navbar': {
            title: 'Основное меню',
        },
        'navbars': [{
            'position': 'bottom',
            'content': [
                '<a target="_blank" href="https://vk.com/biryukovkolya/"><i class="fab fa-vk"></i></a>',
                '<a target="_blank" href="https://telegram.me/biryukovkolya"><i class="fab fa-telegram-plane"></i></a>',
                '<a href="mailto:biryukovkolya@mail.ru"><i class="far fa-envelope"></i></a>'
            ]
        }],
        'extensions': [
            'pagedim-black'
        ]
    }, {
        clone: true
    });
    var $navBarTopToggle = $('#nav-bar__link_toggle');
    var navBarTopAPI = $nabBarMenuTopPlugin.data('mmenu');

    $window.on('resize', function () {
        if ($(this).outerWidth() < 992) {
            $navBarTop.filter('.nav-bar_dark').removeClass('nav-bar_dark')
        } else {
            $navBarTop.not('.nav-bar_dark').addClass('nav-bar_dark')
        }
    });

    $window.trigger('resize');


    $navBarTopToggle.on('click', function () {
        navBarTopAPI.open();
    });

    navBarTopAPI.bind('open:finish', function () {
        $navBarTopToggle.addClass('open');
    });
    navBarTopAPI.bind('close:finish', function () {
        $navBarTopToggle.removeClass('open');
    });
    // end mmenu


    // start scrollspy

    $('[data-scrollspy-class]').each(function () {
        var offsetTop = $(this).offset().top;
        var offsetTopHeight = offsetTop + $(this).outerHeight();
        var min = (offsetTop - $window.outerHeight() > 0) ? offsetTop - $window.outerHeight() : 0;
        var scrollspyData = $(this).data('scrollspy-class');
        $(this).scrollspy({
            min: min,
            max: offsetTopHeight,
            onEnter: function (element) {
                $(element).not('.'+scrollspyData).addClass(scrollspyData)
            },
            onLeave: function (element) {
                $(element).removeClass(scrollspyData)
            }
        });
    });

    $window.trigger('scroll');
    // end scrollspy


    // start inputmask
    var $email = $('#email-address');

    $email.inputmask({
        alias: 'email',
        showMaskOnHover: false
    });
    // end inputmask


    //start slick
    var $homeSlider = $('.home-header');
    $homeSlider.slick({
        autoplay: true,
        arrows: false,
        dots: true
    });
    //end slick

    // start fancybox
    $('[data-fancybox]').fancybox({
        buttons: [
            'slideShow',
            'fullScreen',
            'thumbs',
            // 'share',
            // 'download',
            // 'zoom',
            'close'
        ],
        lang: 'ru',
        i18n: {
            'ru': {
                CLOSE: 'Закрыть',
                NEXT: 'Вперед',
                PREV: 'Назад',
                ERROR: 'Не удалось установить соединение. <br /> Пожалуйста, попробуйте позднее.',
                PLAY_START: 'Начать слайдшоу',
                PLAY_STOP: 'Поставить на паузу',
                FULL_SCREEN: 'На полный экран',
                THUMBS: 'Превьюшки',
                DOWNLOAD: 'Скачать',
                SHARE: 'Поделиться',
                ZOOM: 'Увеличить'
            }
        }
    })
    // end fancybox

    // start main

    // end main

})(jQuery);


// start google maps
function googleMapsLoaderCallback() {
    var mapBlock = document.getElementById('contact-map');
    var latLng = {
        lat: 60.077741,
        lng: 30.341899
    };
    var mapSetting = {
        center: latLng,
        disableDefaultUI: true,
        draggable: false,
        scrollwheel: false,
        zoom: 15
    };
    var dark = {
        styles: [{
            featureType: "all",
            elementType: "all",
            stylers: [{
                invert_lightness: false
            }, {
                saturation: -100
            }, {
                lightness: 20
            }, {
                gamma: 2
            }]
        }],
        name: {
            name: "Dark"
        }
    };

    var styledMapDarkLight = new google.maps.StyledMapType(dark.styles, dark.name);
    var map = new google.maps.Map(mapBlock, mapSetting);
    map.mapTypes.set('Dark', styledMapDarkLight);
    map.setMapTypeId('Dark');
    var infoWindowContent = '<div>' +
        '<p class="font-weight-bold">город Санкт-Петербург</p>' +
        '<p>ул. Федора Абрамова, д.16/1, кв. 16</p>' +
        '</div>';
    var infoWindow = new google.maps.InfoWindow({
        content: infoWindowContent
    });


    var icon = {
        anchor: new google.maps.Point(384 / 2, 512),
        fillOpacity: .7,
        path: "M192 96c-52.935 0-96 43.065-96 96s43.065 96 96 96 96-43.065 96-96-43.065-96-96-96zm0 160c-35.29 0-64-28.71-64-64s28.71-64 64-64 64 28.71 64 64-28.71 64-64 64zm0-256C85.961 0 0 85.961 0 192c0 77.413 26.97 99.031 172.268 309.67 9.534 13.772 29.929 13.774 39.465 0C357.03 291.031 384 269.413 384 192 384 85.961 298.039 0 192 0zm0 473.931C52.705 272.488 32 256.494 32 192c0-42.738 16.643-82.917 46.863-113.137S149.262 32 192 32s82.917 16.643 113.137 46.863S352 149.262 352 192c0 64.49-20.692 80.47-160 281.931z",
        scale: .15,
        scaledSize: new google.maps.Size(384, 512)
    };

    var marker = new google.maps.Marker({
        icon: icon,
        map: map,
        optimized: false,
        position: latLng
    });
    marker.addListener('click', function () {
        infoWindow.open(map, marker);
    });
}

// end google maps