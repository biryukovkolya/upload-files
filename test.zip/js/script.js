$(function(){
  $('.custom-select').chosen({
    disable_search: true,
    inherit_select_classes: true
  });
  
  $('#forma').submit(function(e){
    e.preventDefault();
    var counter = 0;
    var array = $(this).serializeArray();
    var reg_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var reg_name = /^[a-zA-Zа-яА-Я\-\s]{3,}$/;
    if(array.length > 0){
      //console.log(reg_email.test(array[0]['value']));
      if(reg_email.test(array[0]['value'])){
        $(this).find('input[name="email"]').parent().removeClass('error');
        $(this).find('input[name="email"]').parent().addClass('success');
        counter++;
      } else {
        $(this).find('input[name="email"]').parent().addClass('error');
        $(this).find('input[name="email"]').parent().append('<span class="form-mess">Enter correct ' + array[0]['name'] + '</span>');
      }
      if(reg_name.test(array[1]['value'])){
        $(this).find('input[name="name"]').parent().removeClass('error');
        $(this).find('input[name="name"]').parent().addClass('success');
        counter++;
      } else {
        $(this).find('input[name="name"]').parent().addClass('error');
        $(this).find('input[name="name"]').parent().append('<span class="form-mess">Enter correct ' + array[1]['name'] + '</span>');
      }
      if(array[2]['value'] != ''){
        $(this).find('select').parent().removeClass('error');
        $(this).find('select').parent().addClass('success');
        counter++;
      } else {
        $(this).find('select').parent().addClass('error');
        $(this).find('select').parent().append('<span class="form-mess">Chose country ' + array[2]['name'] + '</span>');
      }
      if(array[3]['value'] != ''){
        $(this).find('input[name="terms"]').parent().removeClass('error');
        counter++;
      } else {
        $(this).find('input[name="terms"]').parent().addClass('error');
      }
      if(counter > 3) {
        return true
      } else {
        return false
      }
    }
  });
});
