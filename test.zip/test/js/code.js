$(document).ready(function(){
	var extLink;
	$("select").customSelect();
	$(".list ol li a").on('click', function (event) {
		event.preventDefault();
		extLink = $(this).attr("href");
		$(".modal-overlay, .modal-overlay .modal-win").removeClass("hidden");
	});
	$(".modal-win .close, .modal-win .cancel").on('click', function (event) {
		$(".modal-overlay, .modal-overlay .modal-win").addClass("hidden");
	});
	$(".modal-win .accept").on('click', function (event) {
		$(".modal-overlay, .modal-overlay .modal-win").addClass("hidden");
		window.location = extLink;
	});
});