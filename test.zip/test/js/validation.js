$(function(){
	var form = $('.validationForm'),
		validateBtn = $('.validateBtn'),
		username = $('.name'),
		email = $('.email'),
		country = $('.country'),
		req = $('.req'),
		emailPatt = /^.+@.+[.].{2,}$/i,
		namePatt = /^[-a-zA-Zа-яА-ЯёЁ ]+$/;
	
	function validateEmail(){
		if(!email.val()){
			email.parent().parent().addClass("error").removeClass("errorPatt");
			return false;
		}
		else if(!emailPatt.test(email.val())){
			email.parent().parent().addClass("error").addClass("errorPatt");
			return false;
		}
		return true;
	}
	
	function validateName(){
		if(!username.val()){
			username.parent().parent().addClass("error").removeClass("errorPatt");
			return false;
		}
		else if(!namePatt.test(username.val())){
			username.parent().parent().addClass("error").addClass("errorPatt");
			return false;
		}
		return true;
	}
	
	function resetError(){
		var error = $('.error');
		error.removeClass("error");
	}
	
	function validateCountry(){
		if(!country.val()){
			$('.select_cont .div_option').first().addClass("error");
			return false;
		}
		return true;
	}
	
	function validateChk(){
		if(!req.prop("checked")){
			req.parent().parent().addClass("error");
			return false;
		}
		return true;
	}
	
	
	form.on('submit', function (event) {
		if(!(validateName() && validateEmail() && validateCountry() && validateChk()) ){
			event.preventDefault();
			//resetError();
			validateName();
			validateEmail();
			validateCountry();
			validateChk();
		}
	});
	
	$("input.field[type='text']").on('focus', function (event) {
		$(this).parent().parent().removeClass("error").removeClass("errorPatt").addClass("valid");
	});
	
	email.on('focusout', function (event) {
		if(!emailPatt.test(email.val()) && email.val()){
			$(this).parent().parent().addClass("error").addClass("errorPatt").removeClass("valid");
		}else if(!emailPatt.test(email.val()) && !email.val()){
			$(this).parent().parent().removeClass("valid");
		}
	});	
	
	username.on('focusout', function (event) {
		if(!namePatt.test(username.val()) && username.val()){
			$(this).parent().parent().addClass("error").addClass("errorPatt").removeClass("valid");
		}else if(!namePatt.test(username.val()) && !username.val()){
			$(this).parent().parent().removeClass("valid");
		}
	});
	
	req.on('click', function (event) {
		$(this).parent().parent().removeClass("error");
	});
	
	$("input[type='text'].field").on('input', function (event) {
		if( !$(this).val().length ){
			$(this).parent().find(".reset_field").addClass("hidden");
		}else{
			$(this).parent().find(".reset_field").removeClass("hidden");
		}
	});
	
	$(".reset_field").on('click', function (event) {
		$(this).addClass("hidden");
		$(this).parent().find(".field").val("");
	});

});