<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Test</title>
  <!--[if lt IE 9]> 
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script> 
  <![endif]-->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/chosen.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <section class="banner-blk pos-rel">
    <div class="layer layer-abs"></div>
    <div class="container over">
      <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-6">
          <div class="banner-title h1">Banner header</div>
          <p class="banner-txt fs-18">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
        </div>
        <div class="col-xs-12 col-sm-5 col-sm-offset-1 col-md-4 col-md-offset-1 col-lg-3 col-lg-offset-2">
          <div class="form-blk bg-white col-gray">
            <h3 class="col-blue">Request form</h3>
            <form id="forma" name="forma">
              <div class="form-row mar-b-15 pos-rel">
                <div class="custom-input w-100">
                  <span class="input-hint">Enter your E-Mail</span>
                  <input class="w-100" type="email" name="email" required></input>
                  <span class="close">×</span>
                </div>
              </div>
              <div class="form-row mar-b-15 pos-rel">
                <div class="custom-input w-100">
                  <span class="input-hint">Enter your Name</span>
                  <input class="w-100" type="text" name="name" required></input>
                  <span class="close">×</span>
                </div>
              </div>
              <div class="form-row mar-b-15 pos-rel">
                <select class="custom-select w-100" name="country" data-placeholder="Select Your Options" required>
                  <option class="txt-gray" value="" disabled selected>Select your country</option>
                  <option class="txt-gray" value="rus">Russia</option>
                  <option class="txt-gray" value="usa">USA</option>
                </select>
              </div>
              <div class="form-row mar-b-15">
                <input id="terms" type="checkbox" name="terms" required>
                <label for="terms" class="nowrap">I agree with Terms & Conditions</label>
              </div>
              <div class="form-row row">
                <div class="col-xs-6">
                  <input class="btn w-100" type="submit" value="Submit">
                </div>
                <div class="col-xs-6 algn-c">
                  <a class="form-link" href="#">Hyperlink</a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="posts-blk fs-14">
    <div class="container">
      <div class="row post-row">
        <div class="col-xs-12 col-md-4">
          <div class="post-item post-img-1 mar-b-20">
            <div class="post-txt layer pos-rel" data-toggle="modal" data-target="#myModal">
              <div class="popup-icon"></div>
              <h3>Post header 1</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
          </div>
        </div>
        <div class="col-xs-12 col-md-4">
          <div class="post-item post-img-2 mar-b-20">
            <div class="post-txt layer pos-rel" data-toggle="modal" data-target="#myModal">
              <div class="popup-icon"></div>
              <h3>Post header 2</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
          </div>
        </div>
        <div class="col-xs-12 col-md-4">
          <div class="post-item post-img-3 mar-b-20">
            <div class="post-txt layer pos-rel" data-toggle="modal" data-target="#myModal">
              <div class="popup-icon"></div>
              <h3>Post header 3</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="row post-row">
        <div class="col-xs-12 col-md-6">
          <div class="post-item post-img-4 mar-b-20">
            <div class="post-txt layer pos-rel" data-toggle="modal" data-target="#myModal">
              <div class="popup-icon"></div>
              <h3>Post header 4</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
          </div>
        </div>
        <div class="col-xs-12 col-md-6">
          <div class="post-item post-img-5">
            <div class="post-txt layer pos-rel" data-toggle="modal" data-target="#myModal">
              <div class="popup-icon"></div>
              <h3>Post header 5</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="comp-blk bg-gray col-blue">
    <div class="container">
      <div class="row">
        <div class="col-md-6 hidden-xs hidden-sm">
          <div class="comp-img"><img src="images/comp.png"></div>
        </div>
        <div class="col-xs-12 col-md-6">
          <div class="h1 padd-l-50">Title text</div>
          <ol class="ol-round clean-list h4">
            <li>Duis aute irure dolor in reprehenderit<sup>1</sup> in voluptate velit</li>
            <li>Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
            <li>Ut enim ad minim veniam, quis nostrud exercitation </li>
            <li>Et dolore magna aliqua</li>
            <li>Sed do eiusmod tempor<sup>2</sup> incididunt ut labore</li>
            <li>Lorem ipsum dolor sit amet<sup>3</sup> consectetur adipisicing elit</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <footer class="col-blue fs-18">
    <div class="container">
      <ol class="border-left-blue footnote-list clean-list">
        <li>Reprehenderit - Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore</li>
        <li>Tempor - Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
        <li>Amet - Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</li>
      </ol>
    </div>
  </footer>
  
  <!-- Modal -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h3 class="modal-title">External link</h3>
        </div>
        <div class="modal-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </div>
        <div class="modal-footer">
          <a class="col-gray mar-r-30">Cancel</a>
          <button type="button" class="btn">Accept</button>
        </div>
      </div>
    </div>
  </div>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="js/chosen.jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/script.js"></script>
</body>

</html>
