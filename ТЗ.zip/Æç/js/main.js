$(document).ready(function($) {
	$('#name').on('keypress', function() {
		var that = this;
		setTimeout(function() {
			var res = /[^а-яА-Яa-zA-Z -]/g.exec(that.value);
			that.value = that.value.replace(res, '');
		}, 0);
	});
	$('#email').blur(function() {
						if($(this).val() != '') {
								var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
								if(pattern.test($(this).val())){
										$(this).css({'border' : '1px solid #4488bb'});
										$('.error').css('display','none');
										$('.error-up').css('display','none');
								} else {
										$(this).css({'border' : '1px solid #ff0000'});
										$('.error').css('display','block');
										$('.error-up').css('display','block');
								}
						} else {
								$(this).css({'border' : '1px solid #ff0000'});
								$('.error').css('display','block');
								$('.error-up').css('display','block');
						}
				});

				$('#form').on('change', function() {
					if($('#name').val() != '' && $('#email').val() != ''&& $('select').val() != '' && $('#checkbox').prop('checked')){
						$('#submit').removeAttr("disabled");
					} else {
						$('#submit').attr("disabled", "disabled");
					}
				 });

	$('#openmodal').on("change", function () {
			if($(this).val() === 'openmodaloption')
			$('.popup-fade').fadeIn();
			return false;
	});    

	
	$('.popup-close').click(function() {
			$(this).parents('.popup-fade').fadeOut();
			return false;
	});        

	$(document).keydown(function(e) {
			if (e.keyCode === 27) {
					e.stopPropagation();
					$('.popup-fade').fadeOut();
			}
	});
	
	$('.popup-fade').click(function(e) {
			if ($(e.target).closest('.popup').length == 0) {
					$(this).fadeOut();                    
			}
	});


	
});

