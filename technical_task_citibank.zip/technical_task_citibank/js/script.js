const form = document.querySelector('form');

const tooltipInfoEmail = document.getElementsByTagName('label')[0].querySelector('.tooltip__info');
const tooltipInfoName = document.getElementsByTagName('label')[1].querySelector('.tooltip__info');

let email = document.getElementById('email');
let name = document.getElementById('firstname');
let checkbox = document.getElementById('agree');

email.addEventListener('input', () => {
    if (email.validity.valid) 
        tooltipInfoEmail.className = 'tooltip__info';
});

name.addEventListener('input', () => {
    if (name.validity.valid) 
        tooltipInfoName.className = 'tooltip__info';
});

form.addEventListener('submit', e => {
    if (!email.validity.valid) {
        tooltipInfoEmail.className = 'tooltip__info active';

        setTimeout(() => tooltipInfoEmail.className = 'tooltip__info', 3000);

        e.preventDefault();
    }

    if (!name.validity.valid) {
        tooltipInfoName.className = 'tooltip__info active';

        setTimeout(() => tooltipInfoName.className = 'tooltip__info', 3000);

        e.preventDefault();
    }

    if (!checkbox.checked)
        e.preventDefault();
});
