'use strict'
$(document).ready(function() {
 $('[data-toggle="tooltip"]').tooltip()
var forms = document.getElementsByClassName('contactform');

        window.addEventListener('load', function () {
            var validation = Array.prototype.filter.call(forms, function (form) {
                form.addEventListener('submit', function (event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');

                }, false);

                
            });
        }, false);



//     $('#contactForm').submit(function(event) {
//         event.preventDefault();
//         event.stopPropagation();

//       $(".invalid-tooltip").remove();

//       if (!email) {
//         var pattern = /^[a-z0-9_-]+@[a-z0-9-]+\.[a-z]{2,6}$/i;
//         if (email.search(pattern) == 0) {
//           $('#email').after('<div class="invalid-tooltip">Enter correct E-Mail</div>');
//         }
//       } else {
//         $(this).addClass('was-validated');
//         $('#email').after('<div class="invalid-tooltip">This field is required</div>');
//       }

//       if (!user) {
//         $(this).addClass('was-validated');
//         $('#user').after('<div class="invalid-tooltip">No name entered</div>');
//       } else {
//         var regEx = /^[A-Za-zА-Яа-яЁё]+(\s+[A-Za-zА-Яа-яЁё]+)$/;
//         var validUser = regEx.test(user);
//         if (!validUser) {
//             $(this).addClass('was-validated');
//             $('#user').after('<div class="invalid-tooltip">Not a correct name</div>');
//         }
//       }

//       if (city != '') {
//         $(this).addClass('was-validated');
//         $('#city').after('<div class="invalid-tooltip">Select your sity</div>');
//       }
//     });

  });
  
  function checkParams() {
    var email = $('#email').val();
    var user = $('#user').val();
    var city = $('#city').val(); 
    if(email.length != 0) {
        $('#user').removeAttr('disabled');
    } else {
        $('#user').attr('disabled', 'disabled');
        
    };

    if(user.length != 0){
        console.log(user);
        $('#city').removeAttr('disabled');
    } else {
        $('#city').attr('disabled', 'disabled');
    };
}

