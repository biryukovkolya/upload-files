$(document).ready(function () {
    $('.list__item').on('click',function(){

    $('.popup-bg').fadeIn(500);
    setTimeout(function () {
        $('.popup').addClass('popup_visible').find('.popup__inner').fadeIn(400);
    },200);
});


function closePopup(){
    $('.popup__inner').fadeOut(300);
    setTimeout(function () {
        $('.popup').removeClass('popup_visible');
    },300);
    $('.popup-bg').fadeOut(300);
}

$('.popup__close').on('click',function(){
    closePopup();
});

$(document).on('click',function (e) {
        var target = $(e.target);

        if (target.hasClass('popup_visible')){
            closePopup();
        }
});



/** customize selectors from https://codepen.io/wallaceerick/pen/ctsCz **/

$('select').each(function(){
    var $this = $(this), numberOfOptions = $(this).children('option').length;

    $this.addClass('select-hidden');
    $this.wrap('<div class="select"></div>');
    $this.after('<div class="select-styled"></div>');

    var $styledSelect = $this.next('div.select-styled');
    $styledSelect.text($this.children('option').eq(0).text());

    var $list = $('<ul />', {
        'class': 'select-options'
    }).insertAfter($styledSelect);

    for (var i = 0; i < numberOfOptions; i++) {
        $('<li />', {
            text: $this.children('option').eq(i).text(),
            rel: $this.children('option').eq(i).val()
        }).appendTo($list);
    }

    var $listItems = $list.children('li');

    $styledSelect.click(function(e) {
        e.stopPropagation();
        $('div.select-styled.active').not(this).each(function(){
            $(this).removeClass('active').next('ul.select-options').hide();
        });
        $(this).toggleClass('active').next('ul.select-options').toggle();
    });

    $listItems.click(function(e) {
        e.stopPropagation();
        $styledSelect.text($(this).text()).removeClass('active');
        $this.val($(this).attr('rel')).closest('.form__item').addClass('not-error').removeClass('error');
        $list.hide();
    });

    $(document).click(function() {
        $styledSelect.removeClass('active');
        $list.hide();
    });

});


/**************** Form validation  **********************/
function box_center(el){
	 var left = ($('.form__item').width() - el.outerWidth())/2;	
	 el.css({"left":left});
}

$('.form__input-clean').on('click',function () {
   $(this).closest('.form__item').removeClass('error').removeClass(' not-error').find('.form__input').removeClass('not-empty').val('');
});


$('input#name, input#e-mail, select#country').unbind().blur(function () {

    var id = $(this).attr('id');
    var val = $(this).val();

    if (!val == '') {
        $(this).addClass('not-empty');
    }
    else {
        $(this).removeClass('not-empty');
    }

    switch (id) {
        // Проверка поля "Имя"
        case 'name':
            var rv_name = /^[a-zA-Zа-яА-Я\s-]+$/;

            if (val.length > 2 && val != '' && rv_name.test(val)) {
                $(this).parent().removeClass('error').addClass('not-error');
            }
            else {
				 var box = $(this).parent().find('.form__error-box');			
                box_center(box);
                $(this).parent().removeClass('not-error').addClass('error');
            }
            break;

        // Проверка email
        case 'e-mail':
            var rv_email = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
            if (val != '' && rv_email.test(val)) {
                $(this).parent().removeClass('error').addClass('not-error');
            }
            else {
                var box = $(this).parent().find('.form__error-box');			
                box_center(box);
                $(this).parent().removeClass('not-error').addClass('error');
            }
            break;


    } // end switch(...)

}); // end blur()

$('#user-agreed').on("click",function(){
    if( $('#user-agreed').is( ":checked" )) {
        $('#user-agreed').closest(".form__item").removeClass('error').addClass('not-error');
    }
});

$('form#application').submit(function (e) {

    e.preventDefault();

    if( $('#user-agreed').is( ":checked" )){

        $('#user-agreed').closest(".form__item").removeClass('error');

        if ($('.not-error').length > 3 ) {

            alert("форма отправлена");
            // var curr_form = $(this);
            //
            //     $.ajax({
            //         url: 'application.php',
            //         type: 'post',
            //         data: $(this).serialize(),
            //
            //         success: function(){
            //             $(curr_form).find('.form-item').removeClass('not_error').find('input, textarea').val('').parent();
            //             close_modal();
            //         }
            //     }); // end ajax({...})
        }
        else {	
			$('.form__item').each(function(){
				var curr_item = $(this);
				if (! curr_item.hasClass('not-error')){
					var box = curr_item.find('.form__error-box');			
					box_center(box);
					curr_item.addClass('error');
				}
			});
            return false;
        }
    } else{
        $('#user-agreed').closest(".form__item").addClass('error');

    }


}); // end submit()
});