'use strict';

var gulp = require('gulp');
var sass = require('gulp-sass');
var sourcemaps = require('gulp-sourcemaps');
var concat = require('gulp-concat');  
var uglify = require('gulp-uglify');
var copy = require('gulp-copy');
var postcss = require('gulp-postcss');
var autoprefixer = require('autoprefixer');
var cssnano = require('cssnano');
var clearfix = require('postcss-clearfix');

gulp.task('sass', function () {
  var processors = [
  autoprefixer({browsers: ['last 1 version']}),
      //cssnano(),
      clearfix()
      ];
      gulp.src([
        'sass/style.scss',
        ])
      .pipe(sourcemaps.init())

      .pipe(sass().on('error', sass.logError))
      .pipe(postcss(processors))
      .pipe(concat('style.css'))
      .pipe(sourcemaps.write('./maps/'))
      .pipe(gulp.dest('css/'));

     // console.log('sass задача');
   });

gulp.task('default', function () {
  gulp.watch('sass/*.scss', ['sass']);
});
