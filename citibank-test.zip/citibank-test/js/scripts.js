$(document).ready(function(){
  $('.form-group-material').on('focus', 'input', function (e) {
    var parent = $(this).parent('.form-group-material');
    parent.addClass('focus');
  });

  $('.form-group-material').on('blur', 'input', function (e) {
    if ($(this).val() == "") {
      $(this).parent('.form-group-material').removeClass('focus');	
    }
  });

  $('.form-group-material').on('keyup', '#inp-name', function (e) {
    var $el = $(e.currentTarget);
    var expr = /^[a-zA-Zа-яА-Я][a-zA-Zа-яА-Я-_\.]{1,20}$/;
    var expr = /^[a-zA-Zа-яёА-Я][a-zA-Zа-яёА-Я-_\.]+$/iu;
    var isValid = !expr.test($el.val());
    if (!isValid && $el.val().length > 0) {
      $el.parent('.form-group-material').removeClass('has-error');
    } else {
      $el.parent('.form-group-material').addClass('has-error');
    }
  });

  $('.form-group-material').on('keyup', '#inp-email', function (e) {
    var $el = $(e.currentTarget);
    var expr = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var isValid = !expr.test($el.val());
    if (!isValid) {
      $el.parent('.form-group-material').removeClass('has-error');
    } else {
      $el.parent('.form-group-material').addClass('has-error');
    }
  });

  $(document).on('change', '#sel-country', function (e) {
    if ($(this).val() != 0){
      $(this).removeClass('has-error');
    } else {
      $(this).addClass('has-error');      
    }
  });

   $('.control-checkbox').on('change', '#chb-agree', function (e) {
    if ($(this).is(":checked")){
      $(this).parent('.control-checkbox').removeClass('has-error');
    } else {
      $(this).parent('.control-checkbox').addClass('has-error');
    }

    if ($(this).val() != 0){
      $(this).removeClass('has-error');
    } else {
      $(this).addClass('has-error');      
    }
  });

  $('.form-group-material').on('click', '.btn-clear', function (e) {
    $(this).parent('.form-group-material').removeClass('focus');
    $(this).parent('.form-group-material').find('input').val('');
  });



  $('.request-form').on('submit', function(e){
    e.preventDefault();
    var email = $('#inp-email'),
        name = $('#inp-name'),
        country = $('#sel-country'),
        agree = $('#chb-agree');

    var firmIsValid = email.val().length && name.val().length && (country.val() != 0) && agree.is(":checked");

    if (!firmIsValid) {
      if (email.val().length==0){
        $(email).parent('.form-group-material').addClass('has-error');
      }
      if (name.val().length==0){
        $(name).parent('.form-group-material').addClass('has-error');
      }
      if (country.val() == 0){
        $(country).addClass('has-error');
      }
      if (!agree.is(":checked")){
        $(agree).parent('.control-checkbox').addClass('has-error');
      }
    }
  });

  $('.card').on('click', '.info', function(e){
    $('#myModal').modal('show');
  });

});


