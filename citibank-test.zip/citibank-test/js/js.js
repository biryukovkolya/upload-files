$(document).ready(function() {

  // bootstrap selector
  $('.selectpicker').selectpicker({
    style: '',
  });

  // grid block
  $('.grid .item').mouseover(function () {
    $(this).find('.color_block').addClass('hovered');
  });
  $('.grid .item').mouseout(function () {
    $(this).find('.color_block').removeClass('hovered');
  });


  $('.del').hide();
  $('.del').click(function(argument) {
    $(this).prev().prev().val('');
  });

  $('#form1 input').on('keyup', function() {
    if(this.value != "") {
     $(this).parent().find('.del').show();
   }else {
     $(this).parent().find('.del').hide();
   }   

 })



  
  function validCheckout() {
    var result = [];

    var namePattern = /^\D*$/;
    if ($('#form1 input[name=user_name]').val() == '') {
      $('#form1 input[name=user_name]').css('border', '1px solid #bb4444 ');
      $('#form1 input[name=user_name]').prev().css('color', '#bb4444 ');
      $('#form1 input[name=user_name]').next().show();
      result.push(0);

    } else if ($('#form1 input[name=user_name]').val().length < 3) {
      $('#form1 input[name=user_name]').css('border', '1px solid #bb4444 ');
      $('#form1 input[name=user_name]').prev().css('color', '#bb4444 ');
      $('#form1 input[name=user_name]').next().show();
      result.push(0);


    } else if (!namePattern.test($('#form1 input[name=user_name]').val())) {
      console.log('no dogi');
      $('#form1 input[name=user_name]').css('border', '1px solid #bb4444');
      $('#form1 input[name=user_name]').prev().css('color', '#bb4444 ');
      $('#form1 input[name=user_name]').next().show();
      result.push(0);
    }      else {
      $('#form1 input[name=user_name]').css('border', '1px solid #4488bb ');
      $('#form1 input[name=user_name]').prev().css('color', '#aaa ');
      $('#form1 input[name=user_name]').next().hide();
      result.push(1);
    }


    var emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,6})+$/;

    if ($('#form1 input[name=user_email]').val() == '') {

      $('#form1 input[name=user_email]').css('border', '1px solid #bb4444');
      $('#form1 input[name=user_email]').prev().css('color', '#bb4444 ');
      $('#form1 input[name=user_email]').next().show();
      result.push(0);

    } else if (!emailPattern.test($('#form1 input[name=user_email]').val())) {

      $('#form1 input[name=user_email]').css('border', '1px solid #bb4444');
      $('#form1 input[name=user_email]').prev().css('color', '#bb4444 ');
      $('#form1 input[name=user_email]').next().show();
      result.push(0);
    } else {
      $('#form1 input[name=user_email]').css('border', '1px solid #4488bb');
      $('#form1 input[name=user_email]').prev().css('color', '#aaa ');
      $('#form1 input[name=user_email]').next().hide();
      result.push(1);
    }






    if (!$('#form1 input[name=user_agree]').prop("checked")) {

      $('#form1 input[name=user_agree]').next().css('color', '#bb4444');
      result.push(0);

    }else {

      $('#form1 input[name=user_agree]').next().css('color', '#aaaaaa');

    }





    if ($('#form1 select').val() == "Select your country") {

      $('#form1 .bootstrap-select').css('border', '1px solid #bb4444');
      result.push(0);

    }else {
      $('#form1 .bootstrap-select ').css('border', '1px solid #eee');

    }




    // пост обработчик всех филдов
    var resultSum = 1;
    for(i=0; i < result.length; i++ ) {
      resultSum = resultSum * result[i];

    }    

    if (resultSum === 0 ) {
      return false;
    } else {
      return true;
    }


} // validContact



    //инициация валидации
    $('#form1 button[type=submit]').click(function() {
      $('#form1 input').on('keyup', function() {
        return validCheckout();
      })
      $('#form1 input[type=checkbox]').on('change', function() {
        return validCheckout();
      })
      $('#form1 select').on('change', function() {
        return validCheckout();
      })


      return validCheckout();

    //  return false;
  })

}) // DOC READY


