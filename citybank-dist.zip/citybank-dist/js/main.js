// JavaScript Document
$(document).ready(function(){
	function checkSize(){
		if(window.innerWidth > 1200) {
			return true
		}
	}
	function validateEmail(email) {
		var re = /^([a-z0-9_-]+\.)*[a-z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$/i;
		var place = $(".inp[name='email']").parent();
		
		if(re.test(email)){
			$(place).addClass('valide');
			return true
		} else {
			$(place).addClass('not-valide');
			warnings.messageBlock(warnings.email, place);
			return false;
		};
	}
	function validateName(name) {
		var rename = /^[a-zA-Zа-яёА-ЯЁ-\s]+$/;
		var place = $(".inp[name='name']").parent();
	
		if(name.length > 0 && rename.test(name)){
			$(".inp[name='name']").parent().addClass('valide');
			return true
		} else {
			
			if(!name.length > 0){
				warnings.messageBlock(warnings.name, place);
			} else {
				warnings.messageBlock(warnings.nameCor, place);
			}
			$(place).addClass('not-valide');
			return false;
		}
	}
	function validateSelect(selectVal) {
		if(selectVal == ''){
			var place = $(".inp[name='country']").parent();
			warnings.messageBlock(warnings.country, place);
			return false;  
		} else {
			return true
		};
	}
	function validateCheckbox(checked) {
		if(checked > 0){
			return true
		} else {
			var place = $(".main-form__checkbox").parent().parent();
			warnings.messageBlock(warnings.terms, place);
			return false;  
		};
	}

	function validate() {
		var email = $(".inp[name='email']").val();
		var name = $(".inp[name='name']").val();
		var selectVal = $(".inp[name='country'] option:selected").text();
		var checked = $('.main-form__checkbox:checked').length;
		if (validateEmail(email)  && validateName(name) && validateSelect(selectVal) && validateCheckbox(checked)){
			
		} else {
			return false
		}
	}
	var warnings = {
		email: 'Enter correct E-Mail',
		name: 'Enter your name',
		nameCor: 'Enter correct name',
		country: 'Select the country',
		terms: 'Agree with the Terms and Conditions',
		messageBlock: function(messageTxt, place){
			$(place).append('<div class="main-form__error"><p class="__16">'+ messageTxt + '</p></div>');
		}
	}
	$(".js-validate").bind("click", validate);
	$( "input" ).focus(function(){
		$('.main-form__error').remove();
	});
	$( "input" ).focus(function(){
		$('.main-form__error').remove();
	});
	$('.sec-screen__item').mouseenter(function() {
		if(checkSize()){
			$(this).children().addClass('sec-screen-article_act');
			$(this).find('.sec-screen-article_txt').toggle(500);
		}
	}).mouseleave(function(){
		if(checkSize()){
			$(this).children().removeClass('sec-screen-article_act');
			$(this).find('.sec-screen-article_txt').toggle(500);
		}
	});
	$('.third-screen__item').click(function(){
		$('.modal-win').addClass('modal-win_act');
	});
	$('.js-close-m').click(function(){
		$('.modal-win').removeClass('modal-win_act');
	});
});