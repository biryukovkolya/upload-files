$(document).ready(function(){

	var mail_p = /^[a-z0-9_\.\-]+@([a-z0-9\-]+\.)+[a-z]{2,6}$/i;
	var name_p = /^[a-zа-я]+[a-zа-я\s-]*$/i;

	$('.form-row.check label').click(function(){		
		$(this).toggleClass('ok').removeClass('not-ok');		
		});

	$('#country').on('change',function(){
		$(this).parent().removeClass('not-valid');
	});

	$('#name').on('keyup',function(){

		var $el = $(this);
		var $p = $el.parent();

		if($el.val()){
			if(!name_p.test($el.val())){
				$p.removeClass('is-valid').addClass('not-valid');
			}else{
				$p.removeClass('not-valid').addClass('is-valid');
			}			
		}else{
			$p.removeClass('is-valid not-valid');
		}
	});

	$('form input').on('focus',function(){
		$('#email').parent().removeClass('not-valid');
	});

	$('.form-row .fa-times').click(function(){	
		 $(this).prev().val('').parent().removeClass('is-valid not-valid');
	});

	$('#sub').click(function(){

		var reslut = true;

		var $m = $('#email');
		if(!mail_p.test($m.val()) || !$m.val()){
			$m.parent().removeClass('is-valid').addClass('not-valid');
			reslut = false;
		}else{
			$m.parent().removeClass('not-valid').addClass('is-valid');
		}

		if(!$('#agree').prop('checked')){
			$('#agree').prev().addClass('not-ok');
			reslut = false;
		}	

		if(!$('#name').val() || !$('#name').parent().hasClass('is-valid')){
			$('#name').parent().addClass('not-valid');
			reslut = false;
		}

		if($('#country').val() == 0){
			$('#country').parent().removeClass('is-valid').addClass('not-valid');
			reslut = false;
		}else{
			$('#country').parent().addClass('is-valid');
		}

		return reslut;
	});

	var $title = $('.modal-header span');
	var txt = $title.text();

	$('.list-wrapper li').click(function(){
		var num = ' #' + $(this).find('span').text();		
		$title.text(txt+num);		
		$('.modal-bg').fadeIn();
	});

	$('.modal-wrapper').find('button,img').click(function(){	
		$('.modal-bg').fadeOut();			
	});



});