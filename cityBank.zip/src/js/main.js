$(document).ready(function () {
    var callModalButton = $('.offer li');
    var closeModal = $('.close');
    var cancelButton = $('.modal-inner .cancel')


    callModalButton.click(function () {
        $('.overlay, .modal').addClass('visible')
    });
    closeModal.add(cancelButton).click(function () {
        $('.overlay, .modal').removeClass('visible')
    })
    jQuery(function ($) {
        $(document).mouseup(function (e) { // событие клика по веб-документу
            var div = $(".modal-inner"); // тут указываем ID элемента
            if (!div.is(e.target) // если клик был не по нашему блоку
                &&
                div.has(e.target).length === 0) { // и не по его дочерним элементам
                $('.modal, .overlay').removeClass('visible'); // скрываем его
            }
        });
    });
})

    window.onload = function () {
        var form = document.querySelector('form');
        var name = form.querySelector('input[name=name]');
        var email = form.querySelector('input[name=email]');
        var agree = form.querySelector('input[name=agree')
        var select = form.querySelector('select')

        var nameIsValid
        var emailIsValid
        var isChecked
        var isSelected
        
        function validateEmail() {
            var emailRegExp = /^[\w]{1}[\w-\.]*@[\w-]+\.[a-z]{2,4}$/i
            if (!email.value == '' && emailRegExp.test(email.value)) {
                email.style.border = '1px solid #4488bb'
                email.parentNode.nextElementSibling.style.display = 'none'
                emailIsValid = true
            } else {
                email.parentNode.nextElementSibling.style.display = 'block'
                email.style.border = '1px solid #bb4444'
            }
        }
        function validateName() {
            var nameRegExp = /^[a-zA-Zа-яА-ЯёЁ-\s]+$/
            if (!name.value == '' && nameRegExp.test(name.value)) {
                name.style.border = '1px solid #4488bb'
                name.parentNode.nextElementSibling.style.display = 'none'
                nameIsValid = true
            }else {
                name.style.border = '1px solid #bb4444'
                name.parentNode.nextElementSibling.style.display = 'block'
            }
        }
        function isSelectedCheckbox() {
            if (agree.checked) {
                isChecked = true
                agree.parentNode.querySelector('.message').style.display = 'none'
            } else {
                agree.parentNode.querySelector('.message').style.display = 'block'
            }
        }
        function validateSelect() {
            if (select.selectedIndex > 0) {
                isSelected = true
                select.parentNode.nextElementSibling.style.display = 'none'
            } else {
                select.parentNode.nextElementSibling.style.display = 'block'
            }
        }
        email.onblur = validateEmail;
        name.onblur = validateName;
        agree.onchange = isSelectedCheckbox;
        select.onchange = validateSelect;
        name.oninput = function() {
            var clearButton = this.parentNode.querySelector('.clear')
            clearButton.style.display = 'block'
            if (this.value == '') {
                clearButton.style.display = 'none'
            }
            clearButton.onclick = function(e) {
                e.preventDefault()
                this.parentNode.querySelector('input').value = ''
            }
        }
        email.oninput = function() {
            var clearButton = this.parentNode.querySelector('.clear')
            clearButton.style.display = 'block'
            if (this.value == '') {
                clearButton.style.display = 'none'
            }
            clearButton.onclick = function(e) {
                e.preventDefault()
                this.parentNode.querySelector('input').value = ''
            }
        }
        form.onsubmit = function (e) {
            e.preventDefault()
            validateEmail()
            validateName()
            isSelectedCheckbox()
            validateSelect()
            if (nameIsValid && emailIsValid && isChecked && isSelected) {
                setTimeout("alert ('Форма успешно заполнена!')", 20)
            } else {
                setTimeout("alert('Заполните, пожалуйста, все поля формы!')", 20)
            }
        }

    }