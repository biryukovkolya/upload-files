$(function(){
	$('#form').validate({
		  rules: {
			agree: {
			  required: true
			}
		  },
		messages: {
			name: {
				required: "Enter correct Name",
				name: "Enter correct Name"
			},
			select: {
				required: "Select your country",
				select: "Select your country"
			},
			agree: {
				required: "Check this",
				agree: "Check this"
			},
			email: {
				required: "Enter correct E-Mail",
				email: "Enter correct E-Mail"
			}
		}
	});
});

$(function() {
  jQuery(function($) {
    $('#name').on('keypress', function() {
      var that = this;
      setTimeout(function() {
        var res = /[^A-Za-z�-��-�- ]/g.exec(that.value);
        that.value = that.value.replace(res, '');
      }, 0);
    });
  });
})