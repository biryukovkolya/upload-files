
     $(document).ready(function(){

     
     $('input#name, input#email').unbind().blur( function(){

     
         var id = $(this).attr('id');
         var val = $(this).val();

     
       switch(id)
       {
             // Проверка поля "Имя"
             case 'name':
                var rv_name = /^[а-яА-ЯёЁa-zA-Z -]+$/; // используем регулярное выражение

                

                if(val.length > 2 && val != '' && rv_name.test(val))
                {
                   $(this).addClass('not_error').removeClass('error');
				   $(this).next().next('.del_right').css('display','block');
				   $(this).next().next().next().css('display','none');
                   
                }

              
                else
                {
                   $(this).removeClass('not_error').addClass('error');
                   $(this).next('.del_wrong').css('display','block');
				   $(this).next().next().next().css('display','block');
                }
            break;

           // Проверка email
           case 'email':
               var rv_email = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
               if(val != '' && rv_email.test(val))
               {
                  $(this).addClass('not_error').removeClass('error');
                  $(this).next().next('.del_right').css('display','block');
				  $(this).next().next().next().css('display','none');
               }
               else
               {
                  $(this).removeClass('not_error').addClass('error');
                  $(this).next('.del_wrong').css('display','block');
				   $(this).next().next().next().css('display','block');
               }
           break;


         

       } 

     }); 

	 
	 //Кнопки очистки поля
	 
	 
	 $('.del_wrong').click(function(){
		 $(this).prev("input").removeClass('error').val('');
		 $(this).next().css('display','none');
		 $(this).next().next().css('display','none');
		 $(this).css('display','none');
		 
	 });
	 
	 $('.del_right').click(function(){
		 $(this).prev().prev("input").removeClass('not_error').val('');
		 $(this).next().css('display','none');
		 $(this).next().next().css('display','none');
		 $(this).css('display','none');
		 
	 });
	 
	 
	 //Переключение состояния чекбокса
	 
	 $('#agree').click(function(){
		 
		 if($('#agree').is(":checked"))
		
		{$('#agree').addClass("not_error").removeClass("error");
		$(".agree_lab").addClass("agree_lab_right").removeClass("agree_lab_wrong");
		}
		
		else{$('#agree').removeClass("not_error").addClass("error");
		$(".agree_lab").removeClass("agree_lab_right").addClass("agree_lab_wrong");
		}
		 
		 });
	 
     // Подготовка к отправке AJAX
     $('form#feedback-form').submit(function(e){

         
         e.preventDefault();

         
		 // Проверка чекбокса
		 
		if($('#agree').is(":checked"))
		
		{$('#agree').addClass("not_error").removeClass("error");
		$(".agree_lab").addClass("agree_lab_right").removeClass("agree_lab_wrong");
		}
		
		else{$('#agree').removeClass("not_error").addClass("error");
		$(".agree_lab").removeClass("agree_lab_right").addClass("agree_lab_wrong");
		}
		 
		 // Проверка на запоkytybt имени, почты и чекбокса
		 
         if($('.not_error').length == 3)
         {
            

           /*  $.ajax({
                    url: 'send.php',
                    type: 'post',
                    data: $(this).serialize(),

                    beforeSend: function(xhr, textStatus){ 
                         $('form#feedback-form :input').attr('disabled','disabled');
                    },

                   success: function(response){
                        $('form#feedback-form :input').removeAttr('disabled');
                        $('form#feedback-form :text, textarea').val('').removeClass().next('.error-box').text('');
                        alert(response);
                   }
            }); // end ajax({...})*/
			
			alert("Все поля заполнены и проверены. Форма готова к отправке.")
			
        }

        
        // останавливая отправку сообщения в невалидной форме
       else
       {
	alert("Сообщение 'Заполните все поля'");
		   
          return false;
		  
       }

   }); 

  
  // Модалка
  
  $(".close_pop").click(function(){
	  $(".pop").hide();
  });
   $(".open_pop").click(function(){
	  $(".pop").show('slow');
  });
  
  }); 

  
  