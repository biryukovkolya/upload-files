$(document).ready(function() {
	console.log("Hey guys, i rly need this job! :D");
	console.log("_________________________________");


	$('input[name=Name]').keyup(function(event) {
	    pattern = /^[а-яА-Яa-zA-Z]+$/;
		if(!pattern.test($(this).val())) { $(this).val($(this).val().replace(/[^а-яёa-z ]/gi, ''));
		console.log("Пожалуйста введите ваше имя, например: 'Артур Пирожков' ");
		 }
});

		$('input[name=phone]').keyup(function(event) {
	    pattern = /^[0-9]+$/;
		if(!pattern.test($(this).val())) 
			{ $(this).val($(this).val().replace(/[^0-9+ ]/gi, '')); 
			console.log("Пожалуйста введите ваш номер цифрами (буквы запрещены)");
	}
});





	$(document).on("click", "#form_button", function() {
    	var name = $('input[name=Name]').val();
    	var mail = $('input[name=email]').val();
    	var phone = $('input[name=phone]').val();
        console.log(name + " - was your name input");
        console.log(mail + " - was your mail input");
        console.log(phone + " - was your phone input");

        

        
    
    });
});