$(function(){
    $('#form').validate({
        rules: {
            email: {
                required: true,
                minlenght: 2
            }
        },
        messages: {
            name: {
                required: "Enter you Name",
                minlenght: "Введите не менее 2-х символов в поле 'Имя'"
        },
        email: {
            required: "Enter the Fied",
            email: "Enter correct E-mail"
        },
      
    }
    });
});
