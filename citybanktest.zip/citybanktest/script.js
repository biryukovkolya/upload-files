$(document).ready(function () {
  
  function validate() {
     var email = document.getElementById("email");
     var name = document.getElementById("name");
     var emailError = document.querySelector(".email-error");
     var nameError = document.querySelector(".name-error");
     var checkbox = document.querySelector(".checkbox");
     var checkboxCustom = document.querySelector(".checkbox-custom");
     var selectBox = document.getElementById("select-box");
     var selectedValue = selectBox.options[selectBox.selectedIndex].value;
     var inputDescr = document.querySelector('.input-descr');
     var nameDescr = document.querySelector('.name-descr');
     var regexp = /^[a-zа-яё]+$/i;
     var validEmail = /^\w+@\w+\.\w{2,4}$/i;

     function errorMail() {
        email.style.border = "1px solid #bb4444";
        inputDescr.style.color = "#bb4444";
        email.classList.add("red-color");
        emailError.style.display = "block";
     }
     
      if (!email.value) {
        errorMail();
      }

      else if (email.value) {
        email.style.border = '';
        emailError.style.display = '';
        inputDescr.style.color = '';
      }

      if (!validEmail.test(email.value)) {
        errorMail();
      }

      if (!name.value) {
        name.style.border = "1px solid #bb4444";
        nameDescr.style.color = "#bb4444";
        name.classList.add("red-color");
      }

      else if (name.value) {
        name.style.border = '';
        //nameError.style.display = '';
        nameDescr.style.color = '';
      }

      if (!regexp.test(name.value)) {
         name.style.border = "1px solid #bb4444";
         nameDescr.style.color = "#bb4444";
        name.classList.add("red-color");      }

      if (!checkbox.checked) {
        checkboxCustom.style.border = "1px solid #bb4444";
      }

      else if (checkbox.checked) {
        checkboxCustom.style.border = "";
      }

      if (selectedValue == '') {
        selectBox.style.border = "1px solid #bb4444";
      }
      
       else if (selectedValue !== '') {
        selectBox.style.border = "";
      }
  }

  var submit = document.getElementById("form");
  console.log(submit);
  submit.onclick = function(e) {
    e.preventDefault();
    validate();
    console.log("click submit");
  }
});