$(document).ready(function () {
  function validate() {
     var email = document.getElementById('email').value;
     var name = document.forms['form']['name'].value;

      if (email.length == 0) {
        document.getElementById('emailf').innerHTML='*данное поле обязательно для заполнения';
        return false;
      } 
      else if (name.length == 0) {
        document.getElementById('namef').innerHTML='*данное поле обязательно для заполнения';
        return false;
     } 
      //Проверим содержит ли значение введенное в поле email символы @ и .
      at=email.indexOf("@");
      dot=email.indexOf(".");
      //Если поле не содержит эти символы знач email введен не верно
      if (at<1 || dot <1){
        document.getElementById('emailf').innerHTML='*email введен не верно';
        return false;
   }
  }

  var form = document.getElementById('form');
  form.oclick = function(e) {
    e.preventDefault();
    validate();
  } 
});