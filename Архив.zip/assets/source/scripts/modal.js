$(document).ready(function(){
	$('.promo__list__item__dash').click(function() {
		$('#modal').arcticmodal();
	})
});