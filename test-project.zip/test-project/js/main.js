$(document).ready(function(){

  var popup = $('.popup');
  var popupOverlay = $('.popup-overlay');
  var pseudoPlaceholder = $('.pseudo-placeholder');
  var requestFormInput = $('#request-form input:not(input[type="checkbox"],input[type="submit"])');
  var requestForm = $('#request-form');
  var requestFormBlock = $('.request-form');

  requestFormBlock.animate({
    'opacity':'1'
  },500)

  // popup

  $('.popup-open li').each(function(){
    $(this).on('click', function(){
      popupOverlay.fadeToggle(300);
      popup.fadeToggle(300);
    })
  })

  function closePopup(elem){
    elem.on('click',function(){
      popup.fadeOut(300);
      popupOverlay.fadeOut(300);
    })
  }
  closePopup($('.popup .fa-times'));
  closePopup($('.cancel-button'));

  // inputs pseudo-placeholder

  requestFormInput.each(function(){
    if($(this).val() !== ""){
      $(this).addClass('valid').siblings('.pseudo-placeholder').addClass('focused');
    }
  })

  requestFormInput.focus(function(){
    $(this).siblings('.pseudo-placeholder').addClass('focused')
  })
  requestFormInput.blur(function(){
    if($(this).val() == ""){
      $(this).siblings('.pseudo-placeholder').removeClass('focused')
    }
  })

  requestFormInput.on('change', function(){
    if( $(this).val() == "" && $(this).hasClass('error') == false ){
      $(this).addClass('no-border');
    }
  })

  // form validation

  $(function(){
    requestForm.validate({

      rules: {
  			name: {
  				required: true,
          minlength: 2,
          alphanumeric: true
  			}
  		},
  		messages: {
  			name: {
  				required: "This is required field",
  				minlength: "At least 2 characters"
  			},
  			email: {
  				required: "This is required field",
  				email: "Enter correct email"
  			}
  		}

    });
  })
  $.validator.addMethod('alphanumeric', function (value) {
    return /^[a-zа-я\s\-]+$/mi.test(value);
  }, 'Only letters, space and hyphen');

  requestForm.submit(function(){
    if($('select').val() == "Select-country"){
      if($('.select-error').length<1){
        $('select').after('<span id="select-error" class="select-error">Chose country</span>')
      }
      return false;
    }else if($('#request-form input[type="checkbox"]').prop("checked") == false){
      if($('.checkbox-error').length<1){
        $('#request-form .css-label').after('<span id="input-checkbox-error" class="checkbox-error" for="input-checkbox">Have to agree</span>')
      }
      return false;
    }else{
      alert('Submitted');
      return true;
    }
  })

  $('#request-form input[type="checkbox"]').on('change', function(){
    if($('#request-form input[type="checkbox"]').prop("checked")){
      $('#input-checkbox-error').remove()
    }
  })
  $('#request-form select').change(function(){
    $('#select-error').remove();
  })

  // custom selects

  $('select').styler();


})
