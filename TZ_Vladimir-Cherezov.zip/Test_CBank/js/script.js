/*=======Validation form=======*/
const patternMail = new RegExp('^[.a-z0-9_-]+@[а-яА-Яa-z0-9-]+\.[а-яА-Яa-zA-Z]{2,6}$');
const patternName = new RegExp('[A-Za-zА-Яа-яЁё/\s-]{3,}');
var arrPattern = new Array (patternMail,patternName);
var reqForm = document.getElementById('req_form'); 
function init (element) {
    let inputs = element.getElementsByClassName('hasPlaceholder');
    let placeholders = element.getElementsByClassName('placeholder');
    let clear = element.getElementsByClassName('clear_input');
    let tooltips = element.getElementsByClassName('tooltip'); 
    for(let i=0; i < inputs.length ; i++){ 
        placeholderAttr(placeholders[i],clear[i], inputs[i]);
        inputs[i].onchange = function () {
            let pattern = arrPattern[i];                
            checkValidInput(pattern, inputs[i],tooltips[i],placeholders[i],clear[i]);    
        };             
    };
checkboxSelect();
btnClick();
};    
function placeholderAttr(placeholder,clear,input){
    clearAttr = clear.getAttribute('data-for');
    phAttr = placeholder.getAttribute('data-for');
    inputId = input.getAttribute('id');
    if(phAttr == inputId && clearAttr == inputId){
        input.onfocus = function (){
            placeholder.style.cssText = 'display:block;';
            clear.style.cssText = 'display: block;';
        };           
    } else {
        placeholder.style.cssText = 'display:none;';
    };
    clear.onclick = function () {
        input.value = '';
        clear.style.cssText = 'display: none;';
    };
};         
function checkValidInput(regExp,inp,tooltip,placeholder,clear) {
    if(regExp.test(inp.value)) {
        inp.classList.add('valid');
        inp.classList.remove('invalid');
        tooltip.style.cssText = 'display: none;';
        placeholder.style.cssText = 'display: block; color: #4488bb;';
        clear.style.cssText = 'display: block; color: #4488bb;';
    } else {
        inp.classList.add('invalid');
        inp.classList.remove('valid');
        tooltip.style.cssText = 'display: flex;';
        placeholder.style.cssText = 'display: block; color: #bb4444;';
        clear.style.cssText = 'display: block; color: #bb4444;';
    };
};
function checkboxSelect (){
    let checkbox = document.getElementById('checkbox_agree');
    let select = document.getElementById('user_country');
    checkbox.onclick = function() {
        if(checkbox.hasAttribute('checked') == false) {
            checkbox.setAttribute('checked', 'checked');
            checkbox.classList.add('valid');
        } else {
            checkbox.removeAttribute('checked');
            checkbox.classList.remove('valid');
        };
    };
    select.onchange = function() {
        select.classList.add('valid');
    };
};
function btnClick() {
    let btn = document.getElementById('btn-post');
    let validColl = reqForm.getElementsByClassName('valid');
    btn.onclick = function() {
        if(validColl.length == 4){
            alert('Форма отправлена');
        } else {
            event.preventDefault();
        };
    };
};
    /*=========Modal window========*/
function modalWin(){
    let modalWin = document.getElementById('modal_win');
    let btnAccept = document.getElementById('modal_accept');
    let btnCancel = document.getElementById('modal_cancel');
    let close = document.getElementById('modal_close');
    let overlay = document.getElementById('overlay');
    let list = document.getElementsByClassName('main_promo_list');
    for(let i=0; i < list.length; i++){
        list[i].onclick = function (){
            overlay.style.cssText = 'display: block;';
            modalWin.style.cssText = 'display: block;';
        };
    };
    btnAccept.onclick = function () {
        /*any code*/ 
        overlay.style.cssText = 'display: none;';
        modalWin.style.cssText = 'display: none;';
    };
    btnCancel.onclick = function (){
        overlay.style.cssText = 'display: none;';
        modalWin.style.cssText = 'display: none;';
    };
    close.onclick = function (){
        overlay.style.cssText = 'display: none;';
        modalWin.style.cssText = 'display: none;';
    };
};
window.onload = init(reqForm);
modalWin();